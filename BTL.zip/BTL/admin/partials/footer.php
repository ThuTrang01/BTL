<style>
      p{
          position: relative;
          background-color:#333;
          text-align: center;
          color: white;
          font-size: 30px;
          
      }
      .footerimg{
        
      }
    </style>
</head>
<body>
    <div class="footer">
    <div class="wrapper">
    <p > <img class="footerimg"src="https://icons.iconarchive.com/icons/rafiqul-hassan/blogger/32/Sun-icon.png" alt=""> Bản quyền thuộc về @nhóm 6 CSE485<img src="https://icons.iconarchive.com/icons/rafiqul-hassan/blogger/32/Sun-icon.png" alt=""></p>
    </div>
</div>
</body>
</html>